# MegaMania-Engine

MegaMania Engine is a fork of the Mega Engine made by Wrecking Programs, which mainly adds multiplayer functionality.
The main goal of this repository is to try and make the best megaman engine for gamemaker studio 2 users, as gamemaker 1.4 is slower and outdated (for example, outdated usage of DX9 and lack of new functions)

Any Contribution is welcome, whether it's sprite editing, sound editing, code addition, literally anything to make the engine better.
